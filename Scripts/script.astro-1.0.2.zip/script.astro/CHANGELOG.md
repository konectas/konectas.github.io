

## [v1.0.0](https://github.com/IAmSomeoneLikeYou462/script.astro) (2023-06-19)
 
- First Release

## [v1.0.0](https://github.com/IAmSomeoneLikeYou462/script.astro) (2023-06-19)
 
- First Release

## [v1.0.0](https://github.com/IAmSomeoneLikeYou462/script.astro) (2023-06-20)
 
- First Release

## [v1.0.2](https://github.com/IAmSomeoneLikeYou462/script.astro) (2023-06-27)
 
- Version 1.0.2
### Fixes in this version:
- Added the possibility of remove sections in Astro Remote Config
- Fix table not found when db is not created and there is a astro remote config